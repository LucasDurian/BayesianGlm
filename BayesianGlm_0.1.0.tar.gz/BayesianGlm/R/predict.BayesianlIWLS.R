predict.BayesianlIWLS<-function(x,data){

  X<-model.matrix(x$formula,data = data)
  coe<-x$coefficients
  coe<-as.vector(coe)
  pred<-X %*% coe
  pred<-x$family()$linkinv(pred)
  print(pred)
}
