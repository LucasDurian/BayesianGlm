print.NormalIWLS<- function(x) {

  cat('The formula is:\n')
  cat('               ')
  print(x$formula)
  cat("----","\n")
  cat("The coefficients is:","\n")
  print(t(x$coefficients))
  cat('----','\n')
  cat("The value of significant level is:",x$alpha,"\n")

}
