print.BayesianlIWLS<- function(x) {

  cat('The formula is:\n')
  cat('               ')
  print(x$formula)
  cat("----","\n")
  cat("The coefficients is:","\n")
  print(t(x$coefficients))
  cat('----','\n')
  cat("The value of significant level is:",x$alpha,"\n")
  cat("The mean of prior distribution is:",x$Prior.mu,"\n")
  cat("The variance of prior distribution is:",x$Prior.var,"\n")


}
