Bglm <- function(formula, family=family(),maxit=25, tol=4.440892e-16, alpha=0.05,data,
                 priormu=NULL,priorvar=NULL,intercept=TRUE) {

  if (missing(data)){
    data <- environment(formula)
  }
  mf<-model.frame(formula,data=data)
  x<-model.matrix(formula,data = data)
  y<-model.response(mf,"any")
  y<-model.matrix(~y)[,-1]
  fit <- lm.fit(x=x, y=y, singular.ok=TRUE, tol=1e-07)
  fit $coefficients[is.na(fit$coefficients)] <- 0
  b=fit$coefficients

  rank<-fit$rank
  nobs <- NROW(y)
  weights <- rep.int(1, nobs)
  DFresid <- nobs - rank
  if (nobs < fit$rank)
    stop(gettextf("X matrix has rank %d, but only %d observations, please check and try again",
                  rank, nobs), domain = NA)

  if(missing(priorvar) | missing(priormu)){
    for(j in 1:maxit)
    {
      eta    = x %*% b
      g      = family()$linkinv(eta)
      gprime = family()$mu.eta(eta)
      z      = eta + (y - g) / gprime
      W      = as.vector(gprime^2 / family()$variance(g))
      bold   = b
      b      = solve((crossprod(x,W*x)),(crossprod(x,W*z)), tol=2*.Machine$double.eps)
      if(sqrt(crossprod(b-bold)) < tol) break
    }
  }

  else{

    priorvar<-as.vector(priorvar)
    priormu<-as.vector(priormu)
    Priorvar=1/priorvar
    Priorvar=diag(c(Priorvar))




    for (i in 1:length(priorvar)) {
      if(priorvar[i]<=0){
        stop('The priorvar must bigger than 0, please check and try again')
      }

    }

    if(length(priorvar)!=ncol(x) | length(priormu)!=ncol(x)){

      stop(paste("The number of priorvar and priormu should be: ",NCOL(x),", please try again. Note the correct format should like this: 'c(1,2,3,...)',
                 and the number of your priorvar now is: ",length(priorvar),"the number of your priormu now is: ",length(priormu)))

    }


    for(j in 1:maxit){

      eta    = x %*% b
      g      = family()$linkinv(eta)
      gprime = family()$mu.eta(eta)
      z      = eta + (y - g) / gprime
      W      = as.vector(gprime^2 / family()$variance(g))
      bold   = b
      b      = solve((Priorvar+crossprod(x,W*x)),(diag(Priorvar)*priormu+crossprod(x,W*z)), tol=2*.Machine$double.eps)
      if(sqrt(crossprod(b-bold)) < tol) break
    }
  }
  coef<-matrix(b,dimnames = list(colnames(x),'Estimate'))
  xname<-colnames(x)
  Info<-crossprod(x,W*x)
  S.E<-sqrt(c(diag(solve(Info))))
  s.e<-matrix(S.E,dimnames = list(colnames(x),'std.Error'))
  ci<-matrix(c(b-qnorm(1-alpha/2)*S.E,b+qnorm(1-alpha/2)*S.E),
             nrow = length(b),ncol=2,byrow = F,dimnames = list(colnames(x),c('lower.interval,','higher.interval')))

  Z.value<- b/S.E
  Z.value<-round(Z.value,3)
  zzhi<-matrix(Z.value,dimnames = list(colnames(x),'Z.value'))
  P.value<-2 * pnorm(-abs(Z.value))

  sign<-c(NA)
  for (i in 1:length(P.value)) {
    if(P.value[i]<=0.001){
      sign[i]<-'***'
    }
    else if(P.value[i]<=0.01){
      sign[i]<-'**'
    }
    else if(P.value[i]<=0.05){
      sign[i]<-'*'
    }
    else if(P.value[i]<=0.1){
      sign[i]<-'.'
    }
    else if(P.value[i]<=1){
      sign[i]<-' '
    }
  }


  DFnull <- nobs - as.integer(intercept)
  weightedmu <- sum(weights * y)/sum(weights)
  NULLdev <- sum(family()$dev.resids(y, weightedmu, weights))
  dev <- sum(family()$dev.resids(y, g, weights))
  aic.value <- family()$aic(y, nobs, g, weights, dev) + 2 * rank
  od<-sum(dev/DFresid)
  sign<-matrix(paste(sign, sep=""), ncol=1,dimnames = list(colnames(x),'signif'))
  pzhi<-matrix(P.value,dimnames = list(colnames(x),'p.value'))

  sS.E<-sqrt(c(diag(od*solve(Info))))
  ss.e<-matrix(sS.E,dimnames = list(colnames(x),'std.Error'))
  sci<-matrix(c(b-qnorm(1-alpha/2)*sS.E,b+qnorm(1-alpha/2)*sS.E),
              nrow = length(b),ncol=2,byrow = F,dimnames = list(colnames(x),c('lower.interval,','higher.interval')))
  T.value<-b/sS.E
  T.value<-round(T.value,3)
  tzhi<-matrix(T.value,dimnames = list(colnames(x),'t.value'))
  P.valueoft<-2*pt(-abs(T.value),DFresid)
  spzhi<-matrix(P.valueoft,dimnames = list(colnames(x),'p.value'))

  ssign<-c(NA)
  for (i in 1:length(P.valueoft)) {
    if(P.valueoft[i]<=0.001){
      ssign[i]<-'***'
    }
    else if(P.valueoft[i]<=0.01){
      ssign[i]<-'**'
    }
    else if(P.valueoft[i]<=0.05){
      ssign[i]<-'*'
    }
    else if(P.valueoft[i]<=0.1){
      ssign[i]<-'.'
    }
    else if(P.valueoft[i]<=1){
      ssign[i]<-' '
    }
  }
  ssign<-matrix(paste(ssign, sep=""), ncol=1,dimnames = list(colnames(x),'signif'))
  result<-list(coefficients=coef,iterations=j,confident_interval=ci,information=Info,std.Error=s.e,
               z_value=zzhi,P_value=pzhi,alpha=alpha,xname=xname,sign=sign,formula=formula,Prior.mu=priormu
               ,Prior.var=priorvar,deviance=dev,aic=aic.value,rank=rank,null.deviance = NULLdev
               ,DFresidual=DFresid,DFnull=DFnull,family=family,p_valueoft=spzhi,od=od,t_value=tzhi,
               sstd.Error=ss.e,sconfident_interval=sci,ssign=ssign)

  if(is.null(priormu) | is.null(priorvar)){
    class(result) <- "NormalIWLS"
  }
  if(!is.null(priormu) & !is.null(priorvar)){
    class(result) <- "BayesianlIWLS"
  }
  result
  }


