anova.NormalIWLS<-function(x,y){

  cat("Model 1: ")
  print(x$formula)
  cat("\n")
  cat("Model 2: ")
  print(y$formula)
  cat("\n")

  Df<-c(NA)
  Df[1]=" "
  Df[2]=x$DFresidual - y$DFresidual

  Deviance<-c(NA)
  Deviance[1]=" "
  Deviance[2]=x$deviance - y$deviance

  RES.dev<-c(NA)
  RES.dev[1]=x$deviance
  RES.dev[2]=y$deviance

  RES.df<-c(NA)
  RES.df[1]=x$DFresidual
  RES.df[2]=y$DFresidual

  a<-c(NA)
  a[1]<-" "
  a[2]<-pchisq(abs(x$deviance - y$deviance), df=abs(x$DFresidual - y$DFresidual), lower.tail=FALSE)
  p<-pchisq(abs(x$deviance - y$deviance), df=abs(x$DFresidual - y$DFresidual), lower.tail=FALSE)

  sig<-c(NA)
  sig[1]<-" "
  if(p<=1){
    sig[2]<-' '
  }
  if(p<=0.1){
    sig[2]<-'.'
  }
  if(p<=0.05){
    sig[2]<-'*'
  }
  if(p<=0.01){
    sig[2]<-'**'
  }
  if(p<=0.001){
    sig[2]<-'***'
  }

  table<-cbind(RES.df,RES.dev,Df,Deviance,a,sig)
  table<-as.matrix(table)
  rownames(table)=c("1","2")
  colnames(table)=c("RES.df","RES.dev","Df","Deviance","P.value","signif")

  print(data.frame(table))



}
