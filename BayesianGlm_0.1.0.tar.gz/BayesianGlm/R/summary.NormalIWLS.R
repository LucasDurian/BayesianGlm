summary.NormalIWLS<-function(x) {
  if(x$family()$family %in% c("poisson","binomial")){
  cat('The formula is:\n')
  cat('               ')
  print(x$formula)
  cat("----","\n")
  cat("The value of significant level is:",x$alpha,"\n")
  cat(' ',"\n")
  cat("After" ,x$iterations,"times iterations:","\n")
  cat("The coefficients is:","\n")
  print(data.frame(x$coefficients,x$std.Error,x$z_value,x$P_value,x$sign,x$confident_interval))
  cat("----","\n")
  cat("Signif: 0 *** 0.001 ** 0.01 * 0.05 . 0.1    1 ","\n")
  cat("Residual deviance =", x$deviance,"on",x$DFresidual,"degrees of freedom\n")
  cat("Null deviance =",x$null.deviance,"on",x$DFnull,"degrees of freedom\n")
  cat("AIC =", x$aic,"\n")
  }
  else
{
      cat('The formula is:\n')
      cat('               ')
      print(x$formula)
      cat("----","\n")
      cat("The value of significant level is:",x$alpha,"\n")
      cat(' ',"\n")
      cat("After" ,x$iterations,"times iterations:","\n")
      cat("The coefficients is:","\n")
      print(data.frame(x$coefficients,x$sstd.Error,x$t_value,x$p_valueoft,x$ssign,x$sconfident_interval))
      cat("----","\n")
      cat("Signif: 0 *** 0.001 ** 0.01 * 0.05 . 0.1    1 ","\n")
      cat("Residual deviance =", x$deviance,"on",x$DFresidual,"degrees of freedom\n")
      cat("Null deviance =",x$null.deviance,"on",x$DFnull,"degrees of freedom\n")
      cat("AIC =", x$aic,"\n")
    }


}
